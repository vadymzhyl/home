const sel = document.querySelector("#active-tab")

function select1() {
    sel.style.left = "208px"
    document.getElementById("item1").focus()
}

function select2() {
    sel.style.left = "328px"
    document.getElementById("item2").focus()
}

function select3() {
    sel.style.left = "448px"
    document.getElementById("item3").focus()
}

function select4() {
    sel.style.left = "568px"
    document.getElementById("item4").focus()
}